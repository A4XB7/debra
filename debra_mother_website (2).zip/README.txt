DEAR DEBRA'S MOTHER — WEBSITE

Files:
- index.html — the webpage
- style.css — the design
- script.js — the small entrance animation
- mother-photo.jpeg — the uploaded image

SONG:
Put a song you are allowed to use in this folder and name it:
song.mp3

Then open index.html in a browser.

For GitHub Pages:
1. Create a new GitHub repository.
2. Upload all files from this folder.
3. In Settings → Pages, choose the main branch as the source.
4. Save, then GitHub will provide the website address.
