// Gentle welcome animation
document.addEventListener("DOMContentLoaded", () => {
  const card = document.querySelector(".card");
  card.style.opacity = "0";
  card.style.transform = "translateY(18px)";
  requestAnimationFrame(() => {
    card.style.transition = "opacity 900ms ease, transform 900ms ease";
    card.style.opacity = "1";
    card.style.transform = "translateY(0)";
  });
});
